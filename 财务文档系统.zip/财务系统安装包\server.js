const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const cookieParser = require('cookie-parser');

// ==================== 多语言系统（简化版） ====================
class SimpleI18n {
    constructor() {
        this.translations = {};
        this.currentLang = 'zh-CN';
        this.supportedLangs = ['zh-CN', 'en-US', 'ms-MY'];
        this.loadTranslations();
    }
    
    loadTranslations() {
        const localesDir = path.join(__dirname, 'locales');
        
        // 确保locales目录存在
        if (!fs.existsSync(localesDir)) {
            console.warn('⚠️  警告: locales 目录不存在，正在创建...');
            fs.mkdirSync(localesDir, { recursive: true });
        }
        
        this.supportedLangs.forEach(lang => {
            const filePath = path.join(localesDir, `${lang}.json`);
            if (fs.existsSync(filePath)) {
                try {
                    this.translations[lang] = JSON.parse(fs.readFileSync(filePath, 'utf8'));
                    console.log(`✅  加载语言文件: ${lang}`);
                } catch (error) {
                    console.error(`❌  加载语言文件失败 ${lang}:`, error.message);
                }
            } else {
                console.warn(`⚠️  语言文件不存在: ${filePath}`);
            }
        });
        
        // 如果没有加载到任何语言，使用默认
        if (Object.keys(this.translations).length === 0) {
            console.log('ℹ️  使用默认语言数据');
            this.translations['zh-CN'] = {
                "app": {
                    "title": "财务文档管理系统",
                    "subtitle": "专业财务文档上传、管理、识别一体化解决方案",
                    "features": "支持多格式文件、OCR文本编辑、智能搜索"
                },
                "menu": {
                    "upload": "上传文档",
                    "ocr": "OCR识别",
                    "manage": "文件管理",
                    "pdf": "PDF支持",
                    "search": "全文搜索"
                },
                "upload": {
                    "title": "上传文档",
                    "description": "上传图片、PDF或文档文件，后续可进行OCR文字编辑",
                    "dragDrop": "拖放文件到此处或点击选择文件",
                    "formats": "支持JPG，PNG，PDF，DOC，DOCX，TXT格式，最大50MB"
                },
                "system": {
                    "status": "系统状态",
                    "newUpload": "上传新文档"
                }
            };
        }
    }
    
    t(key, lang = this.currentLang) {
        // 如果请求的语言不存在，使用华语
        if (!this.translations[lang]) {
            lang = 'zh-CN';
        }
        
        const keys = key.split('.');
        let value = this.translations[lang];
        
        for (const k of keys) {
            if (value && typeof value === 'object' && k in value) {
                value = value[k];
            } else {
                // 如果找不到，尝试回退到华语
                if (lang !== 'zh-CN') {
                    return this.t(key, 'zh-CN');
                }
                return key; // 返回键名
            }
        }
        
        return value;
    }
    
    setLanguage(lang) {
        if (this.supportedLangs.includes(lang)) {
            this.currentLang = lang;
            return true;
        }
        return false;
    }
    
    getTranslations(lang) {
        return this.translations[lang] || this.translations['zh-CN'];
    }
}

// 创建多语言实例
const i18n = new SimpleI18n();

const app = express();
const PORT = 3000;

// ==================== 中间件设置 ====================
app.use(express.static('public'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser()); // 添加cookie解析

// 自定义中间件：设置语言
app.use((req, res, next) => {
    // 优先级: 1. URL参数 2. Cookie 3. 默认华语
    let lang = req.query.lang || req.cookies.lang || 'zh-CN';
    
    // 验证语言是否支持
    if (!i18n.supportedLangs.includes(lang)) {
        lang = 'zh-CN';
    }
    
    // 设置当前语言
    i18n.setLanguage(lang);
    
    // 使翻译函数在模板中可用
    res.locals.t = (key) => i18n.t(key);
    res.locals.currentLang = lang;
    res.locals.supportedLangs = i18n.supportedLangs;
    
    // 设置cookie
    res.cookie('lang', lang, { maxAge: 30 * 24 * 60 * 60 * 1000 }); // 30天
    
    next();
});

// 设置视图引擎（如果使用模板）
app.set('view engine', 'ejs'); // 或 'pug', 'handlebars'
app.set('views', path.join(__dirname, 'views'));

// ==================== 文件上传设置 ====================
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        const uploadDir = 'uploads/';
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        const uniqueName = Date.now() + '-' + Math.round(Math.random() * 1E9) + path.extname(file.originalname);
        cb(null, uniqueName);
    }
});

const upload = multer({ 
    storage: storage,
    limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
    fileFilter: function (req, file, cb) {
        const allowedTypes = /jpeg|jpg|png|pdf|doc|docx|txt/;
        const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
        const mimetype = allowedTypes.test(file.mimetype);
        
        if (extname && mimetype) {
            return cb(null, true);
        } else {
            cb(new Error('不支持的文件类型'));
        }
    }
});

// ==================== 路由 ====================

// 首页 - 如果使用模板引擎
app.get('/', (req, res) => {
    // 传递语言数据到模板
    const data = {
        title: i18n.t('app.title'),
        subtitle: i18n.t('app.subtitle'),
        features: i18n.t('app.features'),
        currentLang: res.locals.currentLang,
        supportedLangs: res.locals.supportedLangs
    };
    
    // 如果使用模板引擎
    // res.render('index', data);
    
    // 如果使用静态HTML，重定向到index.html
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ==================== 多语言API ====================

// 切换语言
app.get('/api/language/:lang', (req, res) => {
    const { lang } = req.params;
    
    if (i18n.supportedLangs.includes(lang)) {
        // 设置cookie
        res.cookie('lang', lang, { 
            maxAge: 30 * 24 * 60 * 60 * 1000,
            httpOnly: true 
        });
        
        res.json({ 
            success: true, 
            message: i18n.t('system.status', lang) + ` - 语言已切换到 ${lang}`,
            language: lang 
        });
    } else {
        res.status(400).json({ 
            success: false, 
            message: '不支持的语言',
            supported: i18n.supportedLangs 
        });
    }
});

// 获取当前语言
app.get('/api/language', (req, res) => {
    res.json({ 
        language: res.locals.currentLang,
        supported: i18n.supportedLangs 
    });
});

// 获取翻译数据
app.get('/api/translations/:lang?', (req, res) => {
    const lang = req.params.lang || res.locals.currentLang;
    
    if (i18n.supportedLangs.includes(lang)) {
        res.json(i18n.getTranslations(lang));
    } else {
        res.status(400).json({ 
            error: '不支持的语言',
            supported: i18n.supportedLangs 
        });
    }
});

// 获取所有翻译
app.get('/api/translations', (req, res) => {
    res.json(i18n.translations);
});

// ==================== 文件上传路由 ====================
app.post('/api/upload', upload.array('files'), (req, res) => {
    try {
        if (!req.files || req.files.length === 0) {
            return res.status(400).json({ 
                success: false, 
                message: '没有文件被上传' 
            });
        }
        
        const fileInfo = req.files.map(file => ({
            originalName: file.originalname,
            filename: file.filename,
            size: file.size,
            path: file.path,
            mimetype: file.mimetype
        }));
        
        res.json({ 
            success: true, 
            message: `成功上传 ${fileInfo.length} 个文件`,
            files: fileInfo 
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            message: '上传失败: ' + error.message 
        });
    }
});

// ==================== 系统状态路由 ====================
app.get('/api/status', (req, res) => {
    const status = {
        server: '运行中',
        port: PORT,
        language: res.locals.currentLang,
        uploadsDir: fs.existsSync('uploads/') ? '已创建' : '未创建',
        archivedDir: fs.existsSync('archived/') ? '已创建' : '未创建',
        ocrResultsDir: fs.existsSync('ocr_results/') ? '已创建' : '未创建',
        timestamp: new Date().toISOString()
    };
    
    res.json(status);
});

// ==================== 错误处理 ====================
app.use((req, res) => {
    res.status(404).send(i18n.t('system.status') + ' - 页面未找到');
});

app.use((err, req, res, next) => {
    console.error('服务器错误:', err);
    res.status(500).send(i18n.t('system.status') + ' - 服务器内部错误');
});

// ==================== 启动服务器 ====================
// 确保必要的目录存在
['uploads', 'archived', 'ocr_results', 'public', 'locales'].forEach(dir => {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        console.log(`📁 创建目录: ${dir}/`);
    }
});

app.listen(PORT, () => {
    console.log('='.repeat(60));
    console.log('💰  财务文档管理系统 v2.0 (多语言版)');
    console.log('='.repeat(60));
    console.log(`✅  服务器运行中: http://localhost:${PORT}`);
    console.log(`🌐  支持语言: ${i18n.supportedLangs.join(', ')}`);
    console.log(`📁  文件存储: uploads/`);
    console.log(`📁  归档文件: archived/`);
    console.log(`📄  OCR文本: ocr_results/`);
    console.log('='.repeat(60));
    console.log('🔄  按 Ctrl+C 停止服务器');
    console.log('='.repeat(60));
});